package com.rental.service;

import com.rental.entity.Comment;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * Service class?
 * </p>
 */
public interface ICommentService extends IService<Comment> {
}
