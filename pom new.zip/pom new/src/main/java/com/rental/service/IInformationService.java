package com.rental.service;


import com.baomidou.mybatisplus.service.IService;
import com.rental.entity.Information;

/**
 * <p>
 * Service class?
 * </p>
 */
public interface IInformationService extends IService<Information> {
}
