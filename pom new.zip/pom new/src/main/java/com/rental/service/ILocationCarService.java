package com.rental.service;


import com.baomidou.mybatisplus.service.IService;
import com.rental.entity.LocationCar;

/**
 * <p>
 *  Service class?
 * </p>
 */
public interface ILocationCarService extends IService<LocationCar> {
}
